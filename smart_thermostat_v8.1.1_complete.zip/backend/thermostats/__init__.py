"""
Initialize file for the thermostats app
"""

default_app_config = 'thermostats.apps.ThermostatsConfig'
